package com.epita.cloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudApplicationTests {

	@Test
	void contextLoads() {
	}

}
